# Waiver Reserve Model Governance Note

## 1. Objective

This project calculates Waiver Claim Reserve and Analysis of Movement (AOM) in a controlled, auditable, and reproducible Python workflow.

## 2. Governance principles

### Separation of concerns

- `src/waiver_reserve/`: reusable calculation engine.
- `scripts/`: command line runners.
- `YYYY-MM/config/`: valuation-month assumptions and file pointers.
- `YYYY-MM/data/raw/`: immutable source data snapshot.
- `YYYY-MM/output/`: model output, log, and reconciliation artifacts.

### Reproducibility

Each run includes:

- `run_id`
- `calculation_timestamp`
- `source_path`
- `source_file`
- `valuation_date_used`
- `interest_rate_*_used`
- `usd_to_idr_rate_used`
- config path used for last and this month

### No hidden current working directory dependency

Relative paths in YAML are resolved against the valuation month folder, not against the folder from which Python is executed.

Example:

```yaml
paths:
  masterpolis: data/raw/Master_polis_20260630.xlsx
```

If the config is stored in `waiver/2026-06/config/waiver_assumptions.yaml`, then this path is resolved to:

```text
waiver/2026-06/data/raw/Master_polis_20260630.xlsx
```

## 3. Waiver reserve methodology

For each policy:

```text
Waiver Reserve Base = Annuity Factor x Annual Premium Waived
Waiver Reserve IDR  = Waiver Reserve Base x FX Rate Used
```

Annual Premium Waived:

```text
Annual Premium Waived = Annual Basic Premium + Annual Rider Premium
```

Payment mode factor:

```text
A = 1
S = 2
Q = 4
M = 12
```

## 4. AOM methodology

Bridge order:

| Step | Portfolio | Interest / Yield Curve | FX | Valuation Date |
|---|---|---|---|---|
| Reserve Last Month | Last | Last | Last | Last |
| After Interest Rate | Last | This | Last | Last |
| After FX Rate | Last | This | This | Last |
| After Aging | Last | This | This | This |
| Reserve This Month | This | This | This | This |

Impacts:

```text
Interest Rate Impact = Reserve After Interest - Reserve Last Month
FX Rate Impact       = Reserve After FX - Reserve After Interest
Aging Impact         = Reserve After Aging - Reserve After FX
Portfolio Impact     = Reserve This Month - Reserve After Aging
Total Impact         = Reserve This Month - Reserve Last Month
```

Reconciliation:

```text
Total Impact = Interest Rate Impact + FX Rate Impact + Aging Impact + Portfolio Impact
```

## 5. Control checks

The model performs:

- required column validation
- file existence validation
- duplicate policy warnings
- missing date warnings
- per-policy AOM reconciliation
- summary-level scenario totals

## 6. Recommended monthly close process

1. Create monthly folder `YYYY-MM`.
2. Copy raw input files into `YYYY-MM/data/raw`.
3. Copy config template into `YYYY-MM/config/waiver_assumptions.yaml`.
4. Update valuation date, RFR, FX, and file names.
5. Run single-month reserve.
6. Run AOM after both current and previous month folders are available.
7. Save exported Excel and log file in `YYYY-MM/output`.
8. Lock the monthly folder after close.

## 7. Known limitations / TODO

- Confirm rounding rule for `remaining_waiver_years` against approved Excel methodology.
- Confirm whether expired policy should be fully dropped or retained with zero reserve for reporting.
- Confirm whether rider premium aggregation should include only waiver rider plan codes or additional rider types.
- Confirm IFRS17 yield curve interpretation if forward rate derivation differs from source file.
