from pathlib import Path

from waiver_reserve.config import infer_month_dir_from_config, previous_month


def test_previous_month():
    assert previous_month("2026-06") == "2026-05"
    assert previous_month("2026-01") == "2025-12"


def test_infer_month_dir_from_config():
    path = Path("/tmp/waiver/2026-06/config/waiver_assumptions.yaml")
    assert infer_month_dir_from_config(path) == Path("/tmp/waiver/2026-06")
