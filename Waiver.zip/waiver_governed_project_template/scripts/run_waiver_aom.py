"""CLI runner for Waiver Reserve Analysis of Movement."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from waiver_reserve.aom import run_analysis_of_movement  # noqa: E402
from waiver_reserve.config import build_aom_config_paths  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Waiver Reserve Analysis of Movement.")
    parser.add_argument(
        "--waiver-root",
        default=".",
        help="Waiver project root that contains monthly folders, e.g. C:/.../claim_reserve/waiver",
    )
    parser.add_argument(
        "--this-month",
        required=True,
        help="This valuation month in YYYY-MM format, e.g. 2026-06.",
    )
    parser.add_argument(
        "--last-month",
        default=None,
        help="Optional last valuation month in YYYY-MM format. Default: previous month.",
    )
    parser.add_argument(
        "--config-last",
        default=None,
        help="Optional explicit last month config path. Overrides --waiver-root/--last-month.",
    )
    parser.add_argument(
        "--config-this",
        default=None,
        help="Optional explicit this month config path. Overrides --waiver-root/--this-month.",
    )
    parser.add_argument(
        "--tolerance",
        type=float,
        default=1.0,
        help="Reconciliation tolerance in IDR. Default: 1.",
    )
    parser.add_argument(
        "--output",
        default=None,
        help="Optional explicit output Excel path.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    if args.config_last and args.config_this:
        config_last = Path(args.config_last)
        config_this = Path(args.config_this)
    else:
        config_last, config_this = build_aom_config_paths(
            waiver_root=args.waiver_root,
            this_month=args.this_month,
            last_month=args.last_month,
        )

    output_path = run_analysis_of_movement(
        config_last_path=config_last,
        config_this_path=config_this,
        tolerance=args.tolerance,
        output_path=args.output,
    )

    print(f"\nSUCCESS: Waiver AOM exported to: {output_path}")


if __name__ == "__main__":
    main()
