"""CLI runner for single-month Waiver Reserve."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from waiver_reserve.single_month import run_single_month_reserve  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run single-month Waiver Reserve.")
    parser.add_argument(
        "--config",
        required=True,
        help="Path to monthly waiver_assumptions.yaml, e.g. 2026-06/config/waiver_assumptions.yaml",
    )
    parser.add_argument(
        "--output",
        default=None,
        help="Optional explicit output Excel path.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_path = run_single_month_reserve(config_path=args.config, output_path=args.output)
    print(f"\nSUCCESS: Waiver reserve exported to: {output_path}")


if __name__ == "__main__":
    main()
