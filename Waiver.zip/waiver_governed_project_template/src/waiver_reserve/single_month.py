"""Single-month waiver reserve runner."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pandas as pd

from waiver_reserve.config import load_monthly_config
from waiver_reserve.data_ingestion import load_all_raw_data
from waiver_reserve.export import export_excel
from waiver_reserve.logging_utils import setup_logging
from waiver_reserve.reserve_engine import calculate_waiver_reserve


PRODUCT_DIMENSIONS = ["Company", "Prod_Name", "Plan_Code"]


def build_reserve_summary_by_product(reserve: pd.DataFrame) -> pd.DataFrame:
    """Aggregate single-month reserve by Company, Prod_Name, and Plan_Code."""
    required = PRODUCT_DIMENSIONS + ["policy_number", "waiver_reserve_idr", "annual_premium_waived"]
    missing = [col for col in required if col not in reserve.columns]
    if missing:
        raise KeyError(f"Reserve output missing columns for product summary: {missing}")

    return (
        reserve.groupby(PRODUCT_DIMENSIONS, dropna=False, as_index=False)
        .agg(
            policy_count=("policy_number", "nunique"),
            annual_premium_waived=("annual_premium_waived", "sum"),
            waiver_reserve_idr=("waiver_reserve_idr", "sum"),
        )
        .sort_values(["Company", "Prod_Name", "Plan_Code"])
        .reset_index(drop=True)
    )


def build_reserve_summary_by_company(reserve: pd.DataFrame) -> pd.DataFrame:
    """Aggregate single-month reserve by Company."""
    return (
        reserve.groupby(["Company"], dropna=False, as_index=False)
        .agg(
            policy_count=("policy_number", "nunique"),
            annual_premium_waived=("annual_premium_waived", "sum"),
            waiver_reserve_idr=("waiver_reserve_idr", "sum"),
        )
        .sort_values("Company")
        .reset_index(drop=True)
    )


def run_single_month_reserve(config_path: str | Path, output_path: str | Path | None = None) -> Path:
    """Run waiver reserve for one valuation month."""
    config = load_monthly_config(config_path)
    valuation_month = config.get("_valuation_month", "UNKNOWN")
    run_id = f"WAIVER_RESERVE_{valuation_month}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    setup_logging(config["output_dir"], run_id)
    data = load_all_raw_data(config, run_id=run_id)
    reserve = calculate_waiver_reserve(data=data, config=config, run_id=run_id, scenario_name="BASE")

    summary = pd.DataFrame(
        [
            {
                "run_id": run_id,
                "valuation_month": valuation_month,
                "valuation_date": config.get("valuation_date"),
                "policy_count": len(reserve),
                "waiver_reserve_idr": float(reserve["waiver_reserve_idr"].sum()),
                "config_path": config.get("_config_path"),
                "calculation_timestamp": datetime.now(),
            }
        ]
    )

    summary_by_product = build_reserve_summary_by_product(reserve)
    summary_by_company = build_reserve_summary_by_company(reserve)

    if output_path is None:
        output_path = Path(config["output_dir"]) / f"Waiver_Reserve_{valuation_month}_{run_id}.xlsx"

    return export_excel(
        output_path=output_path,
        sheets={
            "Reserve_Per_Policy": reserve,
            "Summary": summary,
            "Summary_By_Product": summary_by_product,
            "Summary_By_Company": summary_by_company,
        },
    )
