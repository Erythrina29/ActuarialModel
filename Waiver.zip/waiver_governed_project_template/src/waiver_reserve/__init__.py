"""
Waiver Reserve governed calculation package.
"""

__version__ = "0.1.0"
