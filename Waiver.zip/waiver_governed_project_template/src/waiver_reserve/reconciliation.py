"""BOTTOM SECTION: Reconciliation utilities."""

from __future__ import annotations

import logging
from typing import Dict

import pandas as pd

from waiver_reserve.exceptions import ReconciliationError

logger = logging.getLogger("waiver_reserve.reconciliation")


def assert_total_reconciliation(
    df: pd.DataFrame,
    left_col: str,
    right_col: str,
    tolerance: float,
    label: str,
) -> None:
    """Assert two columns reconcile in total."""
    diff = float(df[left_col].sum() - df[right_col].sum())
    logger.info("Reconciliation %s | diff=%.6f", label, diff)

    if abs(diff) > tolerance:
        raise ReconciliationError(f"{label} tidak reconcile. Diff={diff:,.6f}, tolerance={tolerance:,.6f}")


def assert_max_abs_column(
    df: pd.DataFrame,
    column: str,
    tolerance: float,
    label: str,
) -> None:
    """Assert max absolute value in a column is within tolerance."""
    max_abs = float(df[column].abs().max()) if len(df) > 0 else 0.0
    logger.info("Reconciliation %s | max_abs=%.6f", label, max_abs)

    if max_abs > tolerance:
        sample = df[df[column].abs() > tolerance].head(10)
        raise ReconciliationError(
            f"{label} gagal. Max abs diff={max_abs:,.6f}, tolerance={tolerance:,.6f}. "
            f"Sample policy: {sample[['policy_number', column]].to_dict('records')}"
        )


def summarize_numeric_columns(df: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    """Create one-row total summary for selected numeric columns."""
    return pd.DataFrame([{col: float(df[col].sum()) for col in columns}])
