"""
TOP SECTION: Data loading, column standardization, and raw input validation.
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

import pandas as pd

from waiver_reserve.exceptions import DataQualityError

logger = logging.getLogger("waiver_reserve.data_ingestion")


POLICY_COLUMN_MAPPING = {
    "masterpolis": "Policy_Number",
    "waiver_dates": "Policy_Number",
    "crlsrinf": "POLICY_NO",
    "urlsbinf": "POLIS_NO",
    "riderpolis": "PNO",
    "product_mapping": "Policy_number",
}

REQUIRED_COLUMNS = {
    "masterpolis": [
        "policy_number",
        "Status_Policy",
        "Payment_Mode",
        "Insured_Age_at_entry",
        "Sex",
        "Currency",
    ],
    "waiver_dates": ["policy_number", "Waived_Start_Date", "Waived_End_Date"],
    "urlsbinf": ["policy_number", "ANN_REG_PREM_CCY"],
    "crlsrinf": ["policy_number", "Code", "BASIC_PREM_EXTRACT"],
    "mortality_table": ["Age", "MNSQ[x]", "FNSQ[x]"],
    "ifrs17_yield_curve": ["tenure", "usd_rate", "idr_rate"],
    "product_mapping": ["policy_number", "Plan_Code", "Prod_Name", "Company"],
}


def add_audit_columns(df: pd.DataFrame, run_id: str, source_file: str) -> pd.DataFrame:
    """Add raw ingestion audit columns."""
    result = df.copy()
    result["run_id"] = run_id
    result["load_timestamp"] = datetime.now()
    result["source_file"] = Path(source_file).name
    result["source_path"] = str(Path(source_file).resolve())
    return result


def standardize_column_names(df: pd.DataFrame, file_type: str) -> pd.DataFrame:
    """Standardize key columns, especially policy number."""
    result = df.copy()

    # Strip accidental spaces in Excel headers.
    result.columns = [str(col).strip() for col in result.columns]

    old_name = POLICY_COLUMN_MAPPING.get(file_type)
    if old_name and old_name in result.columns:
        result = result.rename(columns={old_name: "policy_number"})
        logger.info("[%s] Rename column %s -> policy_number", file_type, old_name)

    # Defensive aliases for Product_Mapping because Excel headers often vary slightly.
    if file_type == "product_mapping":
        alias_map = {
            "Policy_Number": "policy_number",
            "Policy No": "policy_number",
            "Policy_No": "policy_number",
            "POLICY_NO": "policy_number",
            "POLIS_NO": "policy_number",
            "PNO": "policy_number",
            "Plan Code": "Plan_Code",
            "PLAN_CODE": "Plan_Code",
            "PlanCode": "Plan_Code",
            "Product_Name": "Prod_Name",
            "Product Name": "Prod_Name",
            "PROD_NAME": "Prod_Name",
            "COMPANY": "Company",
        }
        result = result.rename(columns={k: v for k, v in alias_map.items() if k in result.columns})

    if "policy_number" in result.columns:
        result["policy_number"] = result["policy_number"].astype(str).str.strip()

    return result


def validate_required_columns(df: pd.DataFrame, file_type: str) -> None:
    """Validate required columns for a specific raw file type."""
    required = REQUIRED_COLUMNS.get(file_type, [])
    missing = [col for col in required if col not in df.columns]

    if missing:
        raise DataQualityError(f"[{file_type}] Missing required columns: {missing}")


def validate_file_exists(file_path: str | Path, file_type: str) -> Path:
    """Validate raw file exists."""
    path = Path(file_path).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"[{file_type}] File tidak ditemukan: {path}")
    return path


def log_dataframe_info(df: pd.DataFrame, name: str) -> None:
    """Log basic DataFrame metadata."""
    logger.info("[%s] Shape: %s rows x %s columns", name, f"{len(df):,}", len(df.columns))
    logger.info("[%s] Memory: %.2f MB", name, df.memory_usage(deep=True).sum() / (1024**2))

    null_summary = df.isna().sum()
    null_summary = null_summary[null_summary > 0].sort_values(ascending=False)
    if not null_summary.empty:
        logger.warning("[%s] Top null columns: %s", name, dict(null_summary.head(10)))


def load_excel_file(file_path: str | Path, run_id: str, file_type: str, **kwargs: Any) -> pd.DataFrame:
    """Load Excel file and apply audit columns."""
    path = validate_file_exists(file_path, file_type)
    logger.info("Loading [%s]: %s", file_type, path)

    df = pd.read_excel(path, engine="openpyxl", **kwargs)
    df = standardize_column_names(df, file_type)
    df = add_audit_columns(df, run_id, str(path))

    validate_required_columns(df, file_type)
    log_dataframe_info(df, file_type)
    return df


def load_product_mapping(file_path: str | Path, run_id: str) -> pd.DataFrame:
    """
    Load Product_Mapping.xlsx.

    Expected user layout:
    - Sheet name: Sheet1
    - Header starts at B2
    - Columns: Policy_number, Plan_Code, Prod_Name, Company

    Pandas uses zero-based header row index, so B2 header means header=1.
    usecols="B:E" prevents empty Column A from entering the model.
    """
    path = validate_file_exists(file_path, "product_mapping")
    logger.info("Loading [product_mapping]: %s", path)

    df = pd.read_excel(
        path,
        sheet_name="Sheet1",
        header=1,
        usecols="B:E",
        engine="openpyxl",
    )
    df = standardize_column_names(df, "product_mapping")
    df = add_audit_columns(df, run_id, str(path))

    # Remove completely blank rows sometimes left at the bottom of mapping files.
    df = df.dropna(how="all").copy()
    if "policy_number" in df.columns:
        df = df[df["policy_number"].notna()].copy()
        df["policy_number"] = df["policy_number"].astype(str).str.strip()

    validate_required_columns(df, "product_mapping")
    log_dataframe_info(df, "product_mapping")
    return df


def load_ifrs17_yield_curve(file_path: str | Path, run_id: str) -> pd.DataFrame:
    """Load IFRS17 yield curve and standardize expected columns."""
    path = validate_file_exists(file_path, "ifrs17_yield_curve")
    logger.info("Loading IFRS17 yield curve: %s", path)

    df = pd.read_excel(path, sheet_name="Sheet 1", engine="openpyxl")
    df = df.rename(columns={"Tenure": "tenure", "USD": "usd_rate", "IDR": "idr_rate"})
    df = add_audit_columns(df, run_id, str(path))

    validate_required_columns(df, "ifrs17_yield_curve")
    log_dataframe_info(df, "ifrs17_yield_curve")
    return df


def validate_duplicate_policy(df: pd.DataFrame, file_type: str) -> None:
    """
    Log duplicate policy numbers for files expected to be one row per policy.

    This is warning-only because some source files may legitimately have multiple rows
    before aggregation. Hard validation is handled in model enrichment.
    """
    if "policy_number" not in df.columns:
        return

    duplicate_count = df["policy_number"].duplicated().sum()
    if duplicate_count > 0:
        logger.warning("[%s] Duplicate policy_number rows: %s", file_type, f"{duplicate_count:,}")


def load_all_raw_data(config: Dict[str, Any], run_id: str) -> Dict[str, pd.DataFrame]:
    """
    Load all raw data required by waiver reserve.

    The config passed here must already have absolute paths resolved by config.py.
    """
    logger.info("=== TOP: Loading all raw data ===")
    paths = config.get("paths", {})

    data = {
        "masterpolis": load_excel_file(paths["masterpolis"], run_id, "masterpolis"),
        "riderpolis": load_excel_file(paths["riderpolis"], run_id, "riderpolis"),
        "crlsrinf": load_excel_file(paths["crlsrinf"], run_id, "crlsrinf"),
        "urlsbinf": load_excel_file(paths["urlsbinf"], run_id, "urlsbinf"),
        "waiver_dates": load_excel_file(paths["waiver_dates"], run_id, "waiver_dates"),
        "mortality_table": load_excel_file(paths["mortality_table"], run_id, "mortality_table"),
    }

    if paths.get("product_mapping"):
        data["product_mapping"] = load_product_mapping(paths["product_mapping"], run_id)
    else:
        logger.warning("paths.product_mapping tidak ada. Output Prod_Name/Company akan diisi UNMAPPED.")

    if config.get("basis", "Local").upper() == "IFRS17":
        data["ifrs17_yield_curve"] = load_ifrs17_yield_curve(paths["ifrs17_yield_curve"], run_id)
    elif paths.get("ifrs17_yield_curve"):
        # Optional load for audit/reference even under Local basis.
        try:
            data["ifrs17_yield_curve"] = load_ifrs17_yield_curve(paths["ifrs17_yield_curve"], run_id)
        except Exception as exc:  # noqa: BLE001 - warning only by design
            logger.warning("Optional IFRS17 yield curve not loaded: %s", exc)

    for file_type, df in data.items():
        validate_duplicate_policy(df, file_type)

    logger.info("All raw data loaded successfully.")
    return data
