"""
MIDDLE SECTION: Waiver reserve orchestration engine.
"""

from __future__ import annotations

import logging
from copy import deepcopy
from datetime import datetime
from typing import Any, Dict, Optional

import pandas as pd

from waiver_reserve.model import (
    calculate_age_and_remaining_term,
    calculate_annual_premium_waived,
    calculate_annuity_factor,
    enrich_waiver_data,
)

logger = logging.getLogger("waiver_reserve.reserve_engine")


def build_scenario_config(
    base_config: Dict[str, Any],
    interest_rates: Optional[Dict[str, float]] = None,
    usd_to_idr_rate: Optional[float] = None,
    valuation_date: Optional[str] = None,
    basis: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Build explicit scenario config for reserve calculation.

    This fixes the common bug where interest_rates are passed to a helper but
    annuity calculation still reads old rates from config.
    """
    config = deepcopy(base_config)

    if interest_rates is not None:
        config["interest_rate"] = deepcopy(interest_rates)

    if usd_to_idr_rate is not None:
        config["usd_to_idr_rate"] = usd_to_idr_rate

    if valuation_date is not None:
        config["valuation_date"] = valuation_date

    if basis is not None:
        config["basis"] = basis

    return config


def calculate_waiver_reserve(
    data: Dict[str, pd.DataFrame],
    config: Dict[str, Any],
    run_id: str,
    scenario_name: str = "BASE",
    interest_rates: Optional[Dict[str, float]] = None,
    usd_to_idr_rate: Optional[float] = None,
    valuation_date: Optional[str] = None,
    yield_curve: Optional[pd.DataFrame] = None,
) -> pd.DataFrame:
    """
    Calculate waiver reserve for one scenario.

    Parameters with explicit override are used for AOM bridge scenarios.
    """
    scenario_config = build_scenario_config(
        base_config=config,
        interest_rates=interest_rates,
        usd_to_idr_rate=usd_to_idr_rate,
        valuation_date=valuation_date,
    )

    valuation_date_used = scenario_config.get("valuation_date")
    fx_rate_used = float(scenario_config.get("usd_to_idr_rate", 1.0))
    basis_used = scenario_config.get("basis", "Local")

    logger.info("=== Calculate waiver reserve | scenario=%s ===", scenario_name)
    logger.info("valuation_date=%s | basis=%s | usd_to_idr_rate=%s", valuation_date_used, basis_used, fx_rate_used)

    if yield_curve is None:
        yield_curve = data.get("ifrs17_yield_curve")

    df = enrich_waiver_data(data, scenario_config)
    df = calculate_annual_premium_waived(df)
    df = calculate_age_and_remaining_term(df, valuation_date_used)
    df = calculate_annuity_factor(
        df=df,
        mortality_table=data["mortality_table"],
        config=scenario_config,
        yield_curve=yield_curve,
    )

    df["waiver_reserve_base"] = df["annuity_factor"] * df["annual_premium_waived"]
    df["fx_rate_used"] = df["Currency"].astype(str).str.upper().apply(lambda c: fx_rate_used if c == "USD" else 1.0)
    df["waiver_reserve_idr"] = df["waiver_reserve_base"] * df["fx_rate_used"]

    # Audit columns
    df["run_id"] = run_id
    df["scenario_name"] = scenario_name
    df["calculation_timestamp"] = datetime.now()
    df["valuation_date_used"] = valuation_date_used
    df["basis_used"] = basis_used
    df["usd_to_idr_rate_used"] = fx_rate_used

    interest_rate = scenario_config.get("interest_rate", {})
    df["interest_rate_idr_used"] = interest_rate.get("IDR") if isinstance(interest_rate, dict) else None
    df["interest_rate_usd_used"] = interest_rate.get("USD") if isinstance(interest_rate, dict) else None

    logger.info("Scenario %s total reserve: %.2f", scenario_name, df["waiver_reserve_idr"].sum())
    return df
