"""
MIDDLE SECTION: Waiver reserve business logic.

This module intentionally keeps calculation steps explicit for auditability.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

import pandas as pd

from waiver_reserve.exceptions import DataQualityError

logger = logging.getLogger("waiver_reserve.model")


PAYMENT_MODE_FACTOR = {
    "A": 1,
    "S": 2,
    "Q": 4,
    "M": 12,
}


def _as_numeric(series: pd.Series, column_name: str) -> pd.Series:
    """Convert series to numeric and raise error if invalid values are found."""
    converted = pd.to_numeric(series, errors="coerce")
    invalid_count = converted.isna().sum() - series.isna().sum()

    if invalid_count > 0:
        raise DataQualityError(f"Column {column_name} contains {invalid_count:,} non-numeric values.")

    return converted


def enrich_waiver_data(data: Dict[str, pd.DataFrame], config: Dict[str, Any]) -> pd.DataFrame:
    """
    Build model point table for waiver reserve.

    Actuarial interpretation:
    - Only policies with Status_Policy == 'B' are selected as waiver policies.
    - Annual premium waived = annualized basic premium + annualized waiver rider premium.
    """
    logger.info("=== MIDDLE: Enrich waiver model points ===")

    master = data["masterpolis"].copy()
    master["policy_number"] = master["policy_number"].astype(str).str.strip()

    waiver_policies = master[master["Status_Policy"].astype(str).str.strip().eq("B")].copy()
    logger.info("Waiver policies from masterpolis: %s", f"{len(waiver_policies):,}")

    waiver_dates = data["waiver_dates"][["policy_number", "Waived_Start_Date", "Waived_End_Date"]].copy()
    waiver_dates["policy_number"] = waiver_dates["policy_number"].astype(str).str.strip()

    # If duplicate dates exist, keep the latest by waived start/end date and log it.
    duplicate_dates = waiver_dates["policy_number"].duplicated().sum()
    if duplicate_dates > 0:
        logger.warning("waiver_dates duplicate policy rows: %s. Keeping last occurrence.", f"{duplicate_dates:,}")
        waiver_dates = waiver_dates.drop_duplicates("policy_number", keep="last")

    df = waiver_policies.merge(waiver_dates, on="policy_number", how="left", validate="m:1")

    if "product_mapping" in data:
        product_mapping = data["product_mapping"][["policy_number", "Plan_Code", "Prod_Name", "Company"]].copy()
        product_mapping["policy_number"] = product_mapping["policy_number"].astype(str).str.strip()

        duplicate_mapping = product_mapping["policy_number"].duplicated().sum()
        if duplicate_mapping > 0:
            logger.warning(
                "product_mapping duplicate policy rows: %s. Keeping last occurrence.",
                f"{duplicate_mapping:,}",
            )
            product_mapping = product_mapping.drop_duplicates("policy_number", keep="last")

        df = df.merge(product_mapping, on="policy_number", how="left", validate="m:1")
    else:
        df["Plan_Code"] = pd.NA
        df["Prod_Name"] = pd.NA
        df["Company"] = pd.NA

    for col in ["Plan_Code", "Prod_Name", "Company"]:
        df[col] = df[col].fillna("UNMAPPED").astype(str).str.strip()

    unmapped_count = df["Prod_Name"].eq("UNMAPPED").sum()
    if unmapped_count > 0:
        logger.warning("Unmapped product rows in waiver model points: %s", f"{unmapped_count:,}")

    basic_prem = data["urlsbinf"][["policy_number", "ANN_REG_PREM_CCY"]].copy()
    basic_prem["policy_number"] = basic_prem["policy_number"].astype(str).str.strip()
    basic_prem["ANN_REG_PREM_CCY"] = _as_numeric(basic_prem["ANN_REG_PREM_CCY"], "ANN_REG_PREM_CCY")

    duplicate_basic = basic_prem["policy_number"].duplicated().sum()
    if duplicate_basic > 0:
        logger.warning("urlsbinf duplicate policy rows: %s. Aggregating by sum.", f"{duplicate_basic:,}")
        basic_prem = basic_prem.groupby("policy_number", as_index=False)["ANN_REG_PREM_CCY"].sum()

    df = df.merge(basic_prem, on="policy_number", how="left", validate="m:1")

    rider_codes = config.get("waiver_rider_plan_codes", ["CIMACC", "CIMHIS", "CIFACI"])
    crlsrinf = data["crlsrinf"].copy()
    crlsrinf["policy_number"] = crlsrinf["policy_number"].astype(str).str.strip()
    crlsrinf["BASIC_PREM_EXTRACT"] = _as_numeric(crlsrinf["BASIC_PREM_EXTRACT"], "BASIC_PREM_EXTRACT")

    rider_prem = crlsrinf[crlsrinf["Code"].isin(rider_codes)][["policy_number", "BASIC_PREM_EXTRACT"]].copy()
    rider_sum = rider_prem.groupby("policy_number", as_index=False)["BASIC_PREM_EXTRACT"].sum()
    rider_sum = rider_sum.rename(columns={"BASIC_PREM_EXTRACT": "rider_premium"})

    df = df.merge(rider_sum, on="policy_number", how="left", validate="m:1")
    df["rider_premium"] = df["rider_premium"].fillna(0.0)
    df["ANN_REG_PREM_CCY"] = df["ANN_REG_PREM_CCY"].fillna(0.0)

    missing_dates = df["Waived_Start_Date"].isna().sum() + df["Waived_End_Date"].isna().sum()
    if missing_dates > 0:
        logger.warning("Missing waived start/end date cells: %s", f"{missing_dates:,}")

    logger.info("Model points after enrichment: %s", f"{len(df):,}")
    return df


def calculate_annual_premium_waived(df: pd.DataFrame) -> pd.DataFrame:
    """Calculate annual premium waived from payment mode."""
    logger.info("=== MIDDLE: Calculate annual premium waived ===")
    result = df.copy()

    result["Payment_Mode"] = result["Payment_Mode"].astype(str).str.strip()
    result["payment_factor"] = result["Payment_Mode"].map(PAYMENT_MODE_FACTOR).fillna(1).astype(float)

    result["annual_basic_premium"] = result["ANN_REG_PREM_CCY"] * result["payment_factor"]
    result["annual_rider_premium"] = result["rider_premium"] * result["payment_factor"]
    result["annual_premium_waived"] = result["annual_basic_premium"] + result["annual_rider_premium"]

    return result


def calculate_age_and_remaining_term(df: pd.DataFrame, valuation_date: str) -> pd.DataFrame:
    """
    Calculate age at valuation and remaining waiver term.

    Existing Excel logic approximation preserved:
    remaining_waiver_years = max(1, round(years_remaining_raw))
    Expired policies are excluded from reserve calculation.
    """
    logger.info("=== MIDDLE: Calculate age and remaining term ===")
    result = df.copy()

    val_date = pd.to_datetime(valuation_date)
    result["valuation_date_used"] = val_date

    result["Waived_Start_Date"] = pd.to_datetime(result["Waived_Start_Date"], errors="coerce")
    result["Waived_End_Date"] = pd.to_datetime(result["Waived_End_Date"], errors="coerce")
    result["Insured_Age_at_entry"] = _as_numeric(result["Insured_Age_at_entry"], "Insured_Age_at_entry")

    result["years_since_start"] = (val_date - result["Waived_Start_Date"]).dt.days / 365.25
    result["current_age_at_val"] = result["Insured_Age_at_entry"] + result["years_since_start"]
    result["years_remaining_raw"] = (result["Waived_End_Date"] - val_date).dt.days / 365.25

    before = len(result)
    result = result[result["years_remaining_raw"].fillna(-999) >= 0].copy()
    dropped = before - len(result)
    if dropped > 0:
        logger.info("Dropped expired/missing-term policies: %s", f"{dropped:,}")

    result["remaining_waiver_years"] = result["years_remaining_raw"].apply(
        lambda x: max(1, round(x)) if pd.notna(x) else 1
    )

    return result


def _get_local_discount_rate(config: Dict[str, Any], currency: str) -> float:
    """Get local basis flat discount rate by currency."""
    interest_rates = config.get("interest_rate", {"IDR": 0.05, "USD": 0.05})
    return float(interest_rates.get(currency, 0.05))


def _get_ifrs17_discount_factors(
    currency: str,
    remaining: int,
    yield_curve: Optional[pd.DataFrame],
) -> list[float]:
    """Build IFRS17 cumulative discount factors using simplified forward rates."""
    if remaining <= 0:
        return []

    if yield_curve is None or yield_curve.empty:
        forward_rates = [0.05] * remaining
    else:
        rate_col = "usd_rate" if currency == "USD" else "idr_rate"
        curve = yield_curve.copy()
        curve["tenure"] = pd.to_numeric(curve["tenure"], errors="coerce")
        curve[rate_col] = pd.to_numeric(curve[rate_col], errors="coerce")
        curve = curve.dropna(subset=["tenure", rate_col]).sort_values("tenure")
        curve_rates = curve[curve["tenure"] <= remaining][rate_col].tolist()

        if not curve_rates:
            fallback_rate = float(curve[rate_col].iloc[-1]) if not curve.empty else 0.05
            curve_rates = [fallback_rate]

        if len(curve_rates) < remaining:
            curve_rates = curve_rates + [curve_rates[-1]] * (remaining - len(curve_rates))

        forward_rates = [float(x) for x in curve_rates[:remaining]]

    cumulative_df = 1.0
    discount_factors = []
    for forward_rate in forward_rates:
        cumulative_df *= 1 / (1 + forward_rate)
        discount_factors.append(cumulative_df)

    return discount_factors


def _get_qx(mortality_table: pd.DataFrame, age: int, sex: str) -> float:
    """Get mortality rate qx by age and sex."""
    sex = str(sex).strip().upper()
    q_col = "MNSQ[x]" if sex == "M" else "FNSQ[x]"
    q_row = mortality_table[mortality_table["Age"] == age]

    if q_row.empty:
        return 0.01

    qx = pd.to_numeric(q_row.iloc[0][q_col], errors="coerce")
    if pd.isna(qx):
        return 0.01

    return float(qx)


def calculate_annuity_factor(
    df: pd.DataFrame,
    mortality_table: pd.DataFrame,
    config: Dict[str, Any],
    yield_curve: Optional[pd.DataFrame] = None,
) -> pd.DataFrame:
    """Calculate survival-weighted annuity factor for each policy."""
    logger.info("=== MIDDLE: Calculate annuity factor ===")
    result = df.copy()
    basis = str(config.get("basis", "Local")).upper()

    mortality = mortality_table.copy()
    mortality["Age"] = pd.to_numeric(mortality["Age"], errors="coerce")
    mortality = mortality.dropna(subset=["Age"])
    mortality["Age"] = mortality["Age"].astype(int)

    def get_annuity(row: pd.Series) -> float:
        age = row["current_age_at_val"]
        remaining = int(row["remaining_waiver_years"])
        sex = row["Sex"]
        currency = str(row["Currency"]).strip().upper()

        if pd.isna(age) or remaining <= 0:
            return 0.0

        surv = 1.0
        annuity = 0.0

        if basis == "LOCAL":
            interest_rate = _get_local_discount_rate(config, currency)
            discount_factors = [(1 / (1 + interest_rate)) ** k for k in range(remaining)]
        else:
            discount_factors = _get_ifrs17_discount_factors(currency, remaining, yield_curve)

        for k in range(remaining):
            annuity += surv * discount_factors[k]
            current_age = int(round(age + k))
            qx = _get_qx(mortality, current_age, sex)
            surv *= 1 - qx

        return float(annuity)

    result["annuity_factor"] = result.apply(get_annuity, axis=1)
    return result
