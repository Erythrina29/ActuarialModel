"""Logging utilities for auditable model runs."""

from __future__ import annotations

import logging
import sys
from pathlib import Path


def setup_logging(output_dir: str | Path, run_id: str, logger_name: str = "waiver_reserve") -> logging.Logger:
    """
    Configure console and file logging.

    The log file is saved under output/logs/{run_id}.log.
    """
    output_dir = Path(output_dir).expanduser().resolve()
    log_dir = output_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"{run_id}.log"

    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    logger.propagate = False

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    logger.info("Logging initialized")
    logger.info("Run ID: %s", run_id)
    logger.info("Log file: %s", log_file)

    return logger
