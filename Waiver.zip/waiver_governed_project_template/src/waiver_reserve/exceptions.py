"""Custom exceptions for Waiver Reserve model governance."""


class WaiverReserveError(Exception):
    """Base exception for Waiver Reserve errors."""


class ConfigError(WaiverReserveError):
    """Raised when config is missing or invalid."""


class DataQualityError(WaiverReserveError):
    """Raised when input data fails required validation."""


class ReconciliationError(WaiverReserveError):
    """Raised when output does not reconcile within tolerance."""
