"""
TOP SECTION: Config loading and path resolution.

Governance principle:
- Monthly config owns the monthly data snapshot.
- Relative paths in YAML are always resolved relative to the valuation month folder,
  not relative to the current working directory.
"""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Optional

import yaml

from waiver_reserve.exceptions import ConfigError


def read_yaml(config_path: str | Path) -> Dict[str, Any]:
    """Read YAML config file into dictionary."""
    path = Path(config_path).expanduser().resolve()

    if not path.exists():
        raise ConfigError(f"Config file tidak ditemukan: {path}")

    with open(path, "r", encoding="utf-8") as file:
        config = yaml.safe_load(file)

    if not isinstance(config, dict):
        raise ConfigError(f"Config YAML kosong atau formatnya tidak valid: {path}")

    return config


def infer_month_dir_from_config(config_path: str | Path) -> Path:
    """
    Infer valuation month folder from config path.

    Supported layouts:
    1. waiver/2026-06/config/waiver_assumptions.yaml -> waiver/2026-06
    2. waiver/2026-06/waiver_assumptions.yaml        -> waiver/2026-06
    """
    path = Path(config_path).expanduser().resolve()

    if path.parent.name.lower() == "config":
        return path.parent.parent

    return path.parent


def resolve_path(raw_path: str | Path, base_dir: str | Path) -> str:
    """
    Resolve one path.

    Absolute path is preserved.
    Relative path is resolved against base_dir.
    """
    if raw_path is None:
        return raw_path

    path = Path(str(raw_path)).expanduser()
    base = Path(base_dir).expanduser().resolve()

    if path.is_absolute():
        return str(path.resolve())

    return str((base / path).resolve())


def load_monthly_config(config_path: str | Path) -> Dict[str, Any]:
    """
    Load monthly config and resolve all relative paths to absolute paths.

    This is the key function that prevents AOM from accidentally reading 2026-06
    files when it should be reading 2026-05 files.
    """
    config_path = Path(config_path).expanduser().resolve()
    config = read_yaml(config_path)
    config = deepcopy(config)

    month_dir = infer_month_dir_from_config(config_path)

    paths = config.get("paths", {})
    if not isinstance(paths, dict):
        raise ConfigError("Config key 'paths' harus dictionary.")

    resolved_paths = {}
    for key, raw_path in paths.items():
        if raw_path is None:
            resolved_paths[key] = None
        else:
            resolved_paths[key] = resolve_path(raw_path, month_dir)

    config["paths"] = resolved_paths
    config["output_dir"] = resolve_path(config.get("output_dir", "output"), month_dir)
    config["_config_path"] = str(config_path)
    config["_month_dir"] = str(month_dir)
    config["_valuation_month"] = month_dir.name

    validate_monthly_config(config)
    return config


def validate_monthly_config(config: Dict[str, Any]) -> None:
    """Validate minimum config keys required by the model."""
    required_top_level = [
        "valuation_date",
        "basis",
        "usd_to_idr_rate",
        "paths",
        "output_dir",
    ]

    missing = [key for key in required_top_level if key not in config]
    if missing:
        raise ConfigError(f"Config missing required keys: {missing}")

    required_paths = [
        "masterpolis",
        "riderpolis",
        "crlsrinf",
        "urlsbinf",
        "waiver_dates",
        "mortality_table",
    ]

    paths = config.get("paths", {})
    missing_paths = [key for key in required_paths if not paths.get(key)]
    if missing_paths:
        raise ConfigError(f"Config paths missing required files: {missing_paths}")

    basis = str(config.get("basis", "")).upper()
    if basis not in {"LOCAL", "IFRS17"}:
        raise ConfigError("Config key 'basis' harus 'Local' atau 'IFRS17'.")

    if basis == "LOCAL" and "interest_rate" not in config:
        raise ConfigError("Local basis but 'interest_rate' tidak ada di config.")

    if basis == "IFRS17" and not paths.get("ifrs17_yield_curve"):
        raise ConfigError("IFRS17 basis but paths.ifrs17_yield_curve tidak ada.")


def previous_month(month_text: str) -> str:
    """Return previous month in YYYY-MM format."""
    try:
        year, month = [int(x) for x in month_text.split("-")]
    except ValueError as exc:
        raise ConfigError(f"Month harus format YYYY-MM, received: {month_text}") from exc

    if month < 1 or month > 12:
        raise ConfigError(f"Month tidak valid: {month_text}")

    if month == 1:
        return f"{year - 1}-12"

    return f"{year}-{month - 1:02d}"


def default_config_path(waiver_root: str | Path, valuation_month: str) -> Path:
    """Return default monthly config path."""
    return Path(waiver_root).expanduser().resolve() / valuation_month / "config" / "waiver_assumptions.yaml"


def build_aom_config_paths(
    waiver_root: str | Path,
    this_month: str,
    last_month: Optional[str] = None,
) -> tuple[Path, Path]:
    """
    Build last and this month config paths using standardized monthly structure.
    """
    waiver_root = Path(waiver_root).expanduser().resolve()
    last_month = last_month or previous_month(this_month)

    config_last = default_config_path(waiver_root, last_month)
    config_this = default_config_path(waiver_root, this_month)

    if not config_last.exists():
        raise ConfigError(f"Last month config tidak ditemukan: {config_last}")

    if not config_this.exists():
        raise ConfigError(f"This month config tidak ditemukan: {config_this}")

    return config_last, config_this
