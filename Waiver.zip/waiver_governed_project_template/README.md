# Waiver Reserve Governed Project Template

Template ini memisahkan **calculation engine** dari **monthly data snapshot**.

## Recommended structure

```text
waiver/
  src/
    waiver_reserve/
  scripts/
    run_waiver_reserve.py
    run_waiver_aom.py
  config_templates/
    waiver_assumptions.yaml
  docs/
    MODEL_GOVERNANCE.md
  2026-05/
    config/
      waiver_assumptions.yaml
    data/
      raw/
    docs/
    output/
  2026-06/
    config/
      waiver_assumptions.yaml
    data/
      raw/
    docs/
    output/
```

## Setup

```bat
cd "C:\Users\mohammad.firdaus\Documents\pytho_warehouse\claim_reserve\waiver"
py -m pip install -r requirements.txt
```

## Run single-month Waiver Reserve

```bat
cd "C:\Users\mohammad.firdaus\Documents\pytho_warehouse\claim_reserve\waiver"
py scripts\run_waiver_reserve.py --config 2026-06\config\waiver_assumptions.yaml
```

## Run Waiver AOM

```bat
cd "C:\Users\mohammad.firdaus\Documents\pytho_warehouse\claim_reserve\waiver"
py scripts\run_waiver_aom.py --this-month 2026-06
```

By default, AOM will use:

```text
Last month config = 2026-05/config/waiver_assumptions.yaml
This month config = 2026-06/config/waiver_assumptions.yaml
```

You can override explicitly:

```bat
py scripts\run_waiver_aom.py ^
  --config-last 2026-05\config\waiver_assumptions.yaml ^
  --config-this 2026-06\config\waiver_assumptions.yaml ^
  --this-month 2026-06
```

## AOM methodology

Bridge order:

1. Reserve Last Month
2. Interest Rate Impact
3. FX Rate Impact
4. Aging Impact
5. Portfolio Impact
6. Reserve This Month

Per-policy reconciliation:

```text
Reserve This Month
= Reserve Last Month
+ Interest Rate Impact
+ FX Rate Impact
+ Aging Impact
+ Portfolio Impact
```

The script stops if per-policy reconciliation difference exceeds tolerance.
